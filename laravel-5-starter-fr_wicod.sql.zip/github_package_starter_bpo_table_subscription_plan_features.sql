
-- --------------------------------------------------------

--
-- Structure de la table `subscription_plan_features`
--

CREATE TABLE `subscription_plan_features` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `deleted_by` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `subscription_plan_features`
--

INSERT INTO `subscription_plan_features` (`id`, `title`, `created_at`, `updated_at`, `deleted_at`, `created_by`, `updated_by`, `deleted_by`) VALUES
(1, '<strong>1</strong> User', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(2, '<strong>5</strong> Projects', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(3, '<strong>Unlimited</strong> Email Accounts', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(4, '<strong>10GB</strong> Disk Space', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(5, '<strong>100GB</strong> Monthly Bandwidth', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(6, '<strong>10</strong> User', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(7, '<strong>500</strong> Projects', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(8, '<strong>Unlimited</strong> Email Accounts', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(9, '<strong>1000GB</strong> Disk Space', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(10, '<strong>10000GB</strong> Monthly Bandwidth', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(11, '<strong>Unlimted</strong> Users', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(12, '<strong>Unlimited</strong> Projects', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(13, '<strong>Unlimited</strong> Email Accounts', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(14, '<strong>10000GB</strong> Disk Space', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(15, '<strong>Unlimited</strong> Monthly Bandwidth', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL);
