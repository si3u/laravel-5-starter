
-- --------------------------------------------------------

--
-- Structure de la table `navigation_website`
--

CREATE TABLE `navigation_website` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `html_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `html_description` text COLLATE utf8mb4_unicode_ci,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_main` int(11) DEFAULT NULL,
  `list_main_order` int(11) DEFAULT NULL,
  `is_footer` int(11) DEFAULT NULL,
  `list_footer_order` int(11) DEFAULT NULL,
  `is_hidden` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `url_parent_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `deleted_by` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `navigation_website`
--

INSERT INTO `navigation_website` (`id`, `title`, `description`, `html_title`, `html_description`, `slug`, `url`, `icon`, `is_main`, `list_main_order`, `is_footer`, `list_footer_order`, `is_hidden`, `parent_id`, `url_parent_id`, `created_at`, `updated_at`, `deleted_at`, `created_by`, `updated_by`, `deleted_by`) VALUES
(1, 'Accueil', 'Accueil', 'Accueil', 'Accueil', '/', '', 'home', 1, 1, 0, NULL, 0, 0, 0, '2017-09-20 08:53:54', '2017-10-06 14:24:36', NULL, 0, 1, NULL),
(2, 'A Propos', 'À Propos', 'À Propos', 'A Propos de l\'entreprise', 'a-propos', '/a-propos', 'question', 1, 4, 0, NULL, 0, 0, 0, '2017-09-20 08:53:54', '2017-09-29 09:16:54', NULL, 0, 1, NULL),
(3, 'Contact', 'Contact', 'Contact', 'Contact', 'contact', '/contact', NULL, 1, 6, 0, NULL, 0, 0, 0, '2017-09-20 08:53:54', '2017-09-29 09:16:51', NULL, 0, 1, NULL),
(4, 'Autres Pages', 'Autres Pages', 'Autres Pages', 'Autres Pages', 'pages', '/pages', 'file', 1, 7, 0, NULL, 0, 0, 0, '2017-09-20 08:53:54', '2017-09-21 18:10:38', NULL, 0, 1, NULL),
(5, 'Pricing', 'Pricing', 'Pricing', 'Pricing', 'pricing', '/pricing', 'euro', 0, 6, 0, NULL, 1, 0, 0, '2017-09-20 08:53:54', '2017-09-21 18:02:34', NULL, 0, 1, NULL),
(6, '1 Column Page', '1 Column Page', '1 Column Page', '1 Column Page', '1-column', '/pages/1-column', '', 1, 1, 0, NULL, 0, 4, 4, '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(7, '2 Column Page', '2 Column Page', '2 Column Page', '2 Column Page', '2-column', '/pages/2-column', '', 1, 2, 0, NULL, 0, 4, 4, '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(8, '3 Column Page', '3 Column Page', '3 Column Page', '3 Column Page', '3-column', '/pages/3-column', '', 1, 3, 0, NULL, 0, 4, 4, '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(9, '4 Column Page', '4 Column Page', '4 Column Page', '4 Column Page', '4-column', '/pages/4-column', '', 1, 4, 0, NULL, 0, 4, 4, '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(10, 'Changelog', 'Changelog', 'Changelog', 'Changelog', 'changelog', '/changelog', NULL, 0, 5, 0, NULL, 1, 0, 0, '2017-09-20 08:53:54', '2017-09-21 18:02:12', NULL, 0, 1, NULL),
(11, 'Commentaires', 'Commentaires', 'Commentaires', 'Commentaires', 'commentaires', '/commentaires', NULL, 1, 3, 0, NULL, 0, 0, 0, '2017-09-20 08:53:54', '2017-09-29 09:16:54', NULL, 0, 1, NULL),
(12, 'FAQ', 'FAQ', 'FAQ', 'FAQ', 'faq', '/faq', 'question', 1, 5, 0, NULL, 0, 0, 0, '2017-09-21 18:22:13', '2017-09-29 09:16:54', NULL, 1, 1, NULL),
(13, 'Réalisations', 'Toutes les réalisations', 'Réalisations', 'Toutes les réalisations', 'realisations', '/realisations', 'cubes', 1, 2, 0, NULL, 0, 0, 0, '2017-09-25 13:11:37', '2017-09-29 09:16:54', NULL, 1, 1, NULL),
(14, 'Charpentes', 'Charpentes', 'Charpentes', 'Charpentes', 'charpentes', '/realisations/charpentes', NULL, 1, 1, 0, NULL, 0, 13, 13, '2017-09-25 13:12:18', '2017-09-29 09:16:51', NULL, 1, 1, NULL),
(15, 'Terrasses', 'Terrasses', 'Terrasses', 'Terrasses', 'terrasses', '/realisations/terrasses', NULL, 1, 2, 0, NULL, 0, 13, 13, '2017-09-25 13:13:12', '2017-09-29 09:16:51', NULL, 1, 1, NULL);
