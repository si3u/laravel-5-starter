
-- --------------------------------------------------------

--
-- Structure de la table `navigation_admin`
--

CREATE TABLE `navigation_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `help_index_title` text COLLATE utf8mb4_unicode_ci,
  `help_index_content` text COLLATE utf8mb4_unicode_ci,
  `help_create_title` text COLLATE utf8mb4_unicode_ci,
  `help_create_content` text COLLATE utf8mb4_unicode_ci,
  `help_edit_title` text COLLATE utf8mb4_unicode_ci,
  `help_edit_content` text COLLATE utf8mb4_unicode_ci,
  `list_order` int(11) NOT NULL DEFAULT '999',
  `is_hidden` tinyint(4) NOT NULL DEFAULT '0',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `url_parent_id` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `deleted_by` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `navigation_admin`
--

INSERT INTO `navigation_admin` (`id`, `title`, `description`, `slug`, `url`, `icon`, `help_index_title`, `help_index_content`, `help_create_title`, `help_create_content`, `help_edit_title`, `help_edit_content`, `list_order`, `is_hidden`, `parent_id`, `url_parent_id`, `created_at`, `updated_at`, `deleted_at`, `created_by`, `updated_by`, `deleted_by`) VALUES
(1, 'Tableau de Bord', 'Tableau de Bord', '/', '/admin', 'dashboard', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, '2017-09-20 08:53:54', '2017-09-21 09:12:13', NULL, 0, 1, NULL),
(2, 'Analytics', 'Google Analytics', 'analytics', '/admin/analytics', 'line-chart', NULL, NULL, NULL, NULL, NULL, NULL, 9, 0, 0, 0, '2017-09-20 08:53:54', '2017-10-07 08:12:19', NULL, 0, 1, NULL),
(3, 'Sommaire', 'Sommaire Analytics', '/', '/admin/analytics', 'star-half-o', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 2, 2, '2017-09-20 08:53:54', '2017-10-07 08:09:01', NULL, 0, 1, NULL),
(4, 'Périphériques', 'Périphériques', 'devices', '/admin/analytics/devices', 'tablet', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 2, 2, '2017-09-20 08:53:54', '2017-10-07 08:10:38', NULL, 0, 1, NULL),
(5, 'Démographique', 'Démographique', 'demographics', '/admin/analytics/demographics', 'map-marker', NULL, NULL, NULL, NULL, NULL, NULL, 5, 0, 2, 2, '2017-09-20 08:53:54', '2017-10-07 08:03:38', NULL, 0, 1, NULL),
(6, 'Visites et Références', 'Visites et Références', 'visits-and-referrals', '/admin/analytics/visits-and-referrals', 'cloud', NULL, NULL, NULL, NULL, NULL, NULL, 3, 0, 2, 2, '2017-09-20 08:53:54', '2017-10-07 08:08:04', NULL, 0, 1, NULL),
(7, 'Interêts', 'Par Intérêts', 'interests', '/admin/analytics/interests', 'heart', NULL, NULL, NULL, NULL, NULL, NULL, 4, 0, 2, 2, '2017-09-20 08:53:54', '2017-10-07 08:04:54', NULL, 0, 1, NULL),
(8, 'Activités', 'Dernières activités', 'latest-activity', '/admin/latest-activity', 'history', NULL, NULL, NULL, NULL, NULL, NULL, 10, 0, 0, 0, '2017-09-20 08:53:54', '2017-10-07 08:12:19', NULL, 0, 1, NULL),
(9, 'Website', 'Dernières activités Website', 'website', '/admin/latest-activity/website', 'home', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 8, 8, '2017-09-20 08:53:54', '2017-10-07 08:07:33', NULL, 0, 0, NULL),
(10, 'Admin', 'Dernières activités', 'admin', '/admin/latest-activity/admin', 'lock', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 8, 8, '2017-09-20 08:53:54', '2017-10-07 08:01:08', NULL, 0, 0, NULL),
(11, 'Commentaires', 'Commentaires', 'testimonials', '/admin/general/testimonials', 'commenting-o', NULL, NULL, NULL, NULL, NULL, NULL, 3, 0, 17, 17, '2017-09-20 08:53:54', '2017-10-07 08:02:53', NULL, 0, 1, NULL),
(12, 'Locations', 'Locations', 'locations', '/admin/general/locations', 'globe', NULL, NULL, NULL, NULL, NULL, NULL, 4, 0, 17, 17, '2017-09-20 08:53:54', '2017-10-07 08:05:19', NULL, 0, 0, NULL),
(13, 'Pays', 'Pays', 'countries', '/admin/general/locations/countries', 'map-marker', NULL, NULL, NULL, NULL, NULL, NULL, 4, 0, 12, 12, '2017-09-20 08:53:54', '2017-10-07 08:11:10', NULL, 0, 1, NULL),
(14, 'Département', 'Départements', 'provinces', '/admin/general/locations/provinces', 'map-marker', NULL, NULL, NULL, NULL, NULL, NULL, 3, 0, 12, 12, '2017-09-20 08:53:54', '2017-10-07 08:03:49', NULL, 0, 1, NULL),
(15, 'Ville', 'Commune', 'cities', '/admin/general/locations/cities', 'map-marker', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 12, 12, '2017-09-20 08:53:54', '2017-10-07 08:08:18', NULL, 0, 1, NULL),
(16, 'Rue', 'Rue', 'suburbs', '/admin/general/locations/suburbs', 'map-marker', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 12, 12, '2017-09-20 08:53:54', '2017-10-07 08:10:07', NULL, 0, 1, NULL),
(17, 'Général', 'Général Website', 'general', '/admin/general', 'cubes', NULL, NULL, NULL, NULL, NULL, NULL, 6, 0, 0, 0, '2017-09-20 08:53:54', '2017-10-07 08:12:48', NULL, 0, 1, NULL),
(18, 'Rapports', 'Rapports de Contact', 'reports', '/admin/reports', 'bar-chart', NULL, NULL, NULL, NULL, NULL, NULL, 7, 0, 0, 0, '2017-09-20 08:53:54', '2017-10-07 08:12:19', NULL, 0, 1, NULL),
(19, 'Sommaire', 'Sommaire rapports', 'summary', '/admin/reports/summary', 'align-left', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 18, 18, '2017-09-20 08:53:54', '2017-10-07 08:08:45', NULL, 0, 1, NULL),
(20, 'Contact', 'Contact', 'contact-us', '/admin/reports/contact-us', 'comments-o', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 18, 18, '2017-09-20 08:53:54', '2017-10-07 08:03:23', NULL, 0, 1, NULL),
(21, 'Configurations', 'Configurations', 'settings', '/admin/settings', 'cogs', NULL, NULL, NULL, NULL, NULL, NULL, 8, 0, 0, 0, '2017-09-20 08:53:54', '2017-10-07 08:12:19', NULL, 0, 1, NULL),
(22, 'Website', 'Configurations Website', 'website', '/admin/settings/website', 'unlock-alt', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 21, 21, '2017-09-20 08:53:54', '2017-10-07 08:06:24', NULL, 0, 0, NULL),
(23, 'Admin', 'Configurations', 'admin', '/admin/settings/admin', 'lock', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 21, 21, '2017-09-20 08:53:54', '2017-10-07 08:17:36', NULL, 0, 0, NULL),
(24, 'Navigation', 'Navigation Website', 'navigation', '/admin/settings/website/navigation', 'align-center', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 22, 22, '2017-09-20 08:53:54', '2017-10-07 08:05:50', NULL, 0, 0, NULL),
(25, 'Changelogs', '', 'changelogs', '/admin/settings/website/changelogs', 'file-text-o', '', '', '', '', '', '', 2, 0, 22, 22, '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(26, 'Navigation', '', 'navigation', '/admin/settings/admin/navigation', 'align-center', 'Help', '', '', '', '', '', 1, 0, 23, 23, '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(27, 'Administrateurs', 'Administrateurs', 'users', '/admin/settings/admin/users', 'users', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 23, 23, '2017-09-20 08:53:54', '2017-09-21 09:10:43', NULL, 0, 1, NULL),
(28, 'Admin Invites', '', 'invites', '/admin/settings/admin/users/invites', '', '', '', '', '', '', '', 1, 1, 27, 27, '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(29, 'Profil', 'Modifier votre Profil', 'profile', '/admin/profile', 'user', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, 0, '2017-09-20 08:53:54', '2017-10-07 08:11:37', NULL, 0, 1, NULL),
(30, 'Ordre de Navigation', 'Ordre de Navigation', 'order', '/admin/settings/admin/navigation/order', 'list-ol', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 26, 26, '2017-09-20 08:53:54', '2017-09-21 09:30:04', NULL, 0, 1, NULL),
(31, 'Ordre de Navigation', 'Ordre de Navigation Website', 'order', '/admin/settings/website/navigation/order', 'list-ol', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 24, 24, '2017-09-20 08:53:54', '2017-10-07 08:07:00', NULL, 0, 1, NULL),
(32, 'Carrousel Accueil', 'Slider Accueil', 'banners', '/admin/general/banners', 'image', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 17, 17, '2017-09-20 08:53:54', '2017-10-07 08:02:09', NULL, 0, 1, NULL),
(33, 'Souscriptions', 'Plans de Souscription', 'subscription-plans', '/admin/settings/website/subscription-plans', 'money', NULL, NULL, NULL, NULL, NULL, NULL, 3, 0, 22, 22, '2017-09-20 08:53:54', '2017-09-21 09:28:25', NULL, 0, 1, NULL),
(34, 'Rôles', 'Roles', 'roles', '/admin/settings/roles', 'universal-access', NULL, NULL, NULL, NULL, NULL, NULL, 3, 0, 21, 21, '2017-09-20 08:53:54', '2017-09-21 09:11:07', NULL, 0, 1, NULL),
(35, 'Fonctionnalités', 'Fonctionnalités', 'features', '/admin/settings/website/subscription-plans/features', 'tags', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 33, 33, '2017-09-20 08:53:54', '2017-09-21 09:13:26', NULL, 0, 1, NULL),
(36, 'Réalisations', 'Réalisations', 'blog', '/admin/blog', 'newspaper-o', NULL, NULL, NULL, NULL, NULL, NULL, 3, 0, 0, 0, '2017-09-20 08:53:54', '2017-10-07 08:12:19', NULL, 0, 1, NULL),
(37, 'Réalisations', 'Réalisations', 'articles', '/admin/blog/articles', 'list', NULL, NULL, NULL, NULL, NULL, 'Pour ajouter des images à la réalisation, il suffit de se servir du bouton \"Image\" <i class=\"faf fa-picture-o\"></i> présent dans la barre d\'outil de l\'éditeur de texte.', 2, 0, 36, 36, '2017-09-20 08:53:54', '2017-10-07 08:09:25', NULL, 0, 1, NULL),
(38, 'Catégories', 'Catégories des réalisations', 'categories', '/admin/blog/categories', 'cubes', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 36, 36, '2017-09-20 08:53:54', '2017-10-07 08:02:25', NULL, 0, 1, NULL),
(39, 'Etiquettes', 'Etiquettes', 'tags', '/admin/general/tags', 'tags', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 17, 17, '2017-09-20 08:53:54', '2017-10-07 08:04:01', NULL, 0, 1, NULL),
(40, 'FAQ', 'FAQ', 'faqs', '/admin/faqs', 'question', NULL, NULL, NULL, NULL, NULL, NULL, 5, 0, 0, 0, '2017-09-20 08:53:54', '2017-10-07 08:12:47', NULL, 0, 1, NULL),
(41, 'FAQ Questions', 'FAQ Questions', NULL, '/admin/faqs', 'question', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 40, 40, '2017-09-20 08:53:54', '2017-10-07 08:04:26', NULL, 0, 0, NULL),
(42, 'Catégories', 'Catégories FAQ', 'categories', '/admin/faqs/categories', 'cubes', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 40, 40, '2017-09-20 08:53:54', '2017-10-07 08:17:05', NULL, 0, 1, NULL),
(43, 'Paramètres', 'Paramètres', 'parameters', '/admin/settings/parameters', 'cog', NULL, NULL, NULL, NULL, NULL, NULL, 4, 0, 21, 21, '2017-09-22 07:23:32', '2017-10-04 07:29:56', NULL, 1, 1, NULL),
(44, 'Actualités', 'Actualités', 'actus', '/admin/actus', 'cube', NULL, NULL, NULL, 'Choisissez bien votre titre.', NULL, NULL, 4, 0, 0, 0, '2017-10-02 08:43:05', '2017-10-07 08:12:19', NULL, 1, 1, NULL);
