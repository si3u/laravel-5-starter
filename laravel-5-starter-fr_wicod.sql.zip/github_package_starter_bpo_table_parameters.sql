
-- --------------------------------------------------------

--
-- Structure de la table `parameters`
--

CREATE TABLE `parameters` (
  `id` int(11) NOT NULL,
  `params` varchar(20) NOT NULL,
  `value` text NOT NULL,
  `deleted_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `parameters`
--

INSERT INTO `parameters` (`id`, `params`, `value`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'keywords', '[\"mots\",\"clé\"]', '0000-00-00 00:00:00', '2017-09-22 00:00:00', '2017-10-04 12:11:37'),
(2, 'description', '\"Description Description Description Description Description Description Description  Description  Description  Description\"', '0000-00-00 00:00:00', '2017-09-23 00:00:00', '2017-10-06 17:29:14'),
(3, 'horaires', '{\"open1_lundi\":\"10h00\",\"close1_lundi\":\"12h00\",\"open2_lundi\":\"14h00\",\"close2_lundi\":\"18h00\",\"open1_mardi\":\"10h00\",\"close1_mardi\":\"12h00\",\"open2_mardi\":\"14h00\",\"close2_mardi\":\"18h00\",\"open1_mercredi\":\"10h00\",\"close1_mercredi\":\"12h00\",\"open2_mercredi\":\"ferm\\u00e9\",\"close2_mercredi\":null,\"open1_jeudi\":\"10h00\",\"close1_jeudi\":\"12h00\",\"open2_jeudi\":\"14h00\",\"close2_jeudi\":\"18h00\",\"open1_vendredi\":\"10h00\",\"close1_vendredi\":\"12h00\",\"open2_vendredi\":\"14h00\",\"close2_vendredi\":\"18h00\",\"open1_samedi\":\"10h00\",\"close1_samedi\":\"12h00\",\"open2_samedi\":\"ferm\\u00e9\",\"close2_samedi\":null}', '0000-00-00 00:00:00', '2017-09-23 00:00:00', '2017-10-04 11:33:28'),
(4, 'infos', '{\"nom\":\"\",\"prenom\":\"\",\"societe\":\"Starter WICOD\",\"slogan\":null,\"siret\":\"123456789 12345\",\"statut\":\"\",\"capital\":\"\",\"telfixe\":\"06 12 34 56 78\",\"telmobile\":null,\"rue\":\"\",\"cp\":\"88220\",\"ville\":\"Arches\",\"region\":\"Vosges\",\"longitude\":\"48.118004\",\"latitude\":\"6.528363\"}', '0000-00-00 00:00:00', '2017-09-23 00:00:00', '2017-10-04 11:33:55'),
(5, 'socials', '{\"facebookappid\":\"12345678\",\"twitterpage\":\"@\"}', '0000-00-00 00:00:00', '2017-09-25 00:00:00', '2017-10-04 11:34:08');
