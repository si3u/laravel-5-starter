
-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keyword` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `deleted_by` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `roles`
--

INSERT INTO `roles` (`id`, `icon`, `name`, `slug`, `keyword`, `summary`, `created_at`, `updated_at`, `deleted_at`, `created_by`, `updated_by`, `deleted_by`) VALUES
(1, 'user', 'Website', '/', 'website', NULL, '2017-09-20 08:53:53', '2017-09-20 08:53:53', NULL, 0, 0, NULL),
(2, 'user-secret', 'Basic Admin', '/admin', 'admin', NULL, '2017-09-20 08:53:53', '2017-09-20 08:53:53', NULL, 0, 0, NULL),
(3, 'user-circle', 'Analytics', '/admin', 'analytics', NULL, '2017-09-20 08:53:53', '2017-09-20 08:53:53', NULL, 0, 0, NULL),
(4, 'user-secret', 'Admin', '/admin', 'admin_super', NULL, '2017-09-20 08:53:53', '2017-09-20 08:53:53', NULL, 0, 0, NULL),
(5, 'universal-access', 'Développeur', '/admin', 'developer', NULL, '2017-09-20 08:53:53', '2017-09-20 08:53:53', NULL, 0, 0, NULL);
