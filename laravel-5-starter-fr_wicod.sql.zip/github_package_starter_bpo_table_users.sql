
-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `firstname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cellphone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `born_at` date DEFAULT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_updated_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmation_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logged_in_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(10) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `cellphone`, `telephone`, `image`, `gender`, `born_at`, `password`, `password_updated_at`, `remember_token`, `confirmation_token`, `logged_in_at`, `created_at`, `updated_at`, `confirmed_at`, `deleted_by`, `deleted_at`) VALUES
(1, 'Admin', 'Admin', 'admin@mail.com', '0123456789', NULL, '1006ce8ab2b1d2904520e64acf7e13babdb80113.png', 'Mr', NULL, '$2y$10$Her1jzgk3ULP.1RtOUtjCOXiaWUOCOaJN4gkJ0GjmsIm/D01Wf7i6', NULL, 'aDE3ydXLz7dubD95Tk7K7djAhpUcbmpjs0huJE6bUCzocs0z4FCjT7uNx1bf', NULL, '2017-10-08 15:37:37', '2017-09-20 08:53:54', '2017-10-08 15:37:37', '2017-09-20 08:53:54', NULL, NULL),
(2, 'BasicAdmin', 'Basic', 'basic-admin@mail.com', '0123456789', NULL, '79d0d177d03260104fc9632237f54367bd38bb31.png', 'Mme', NULL, '$2y$10$Her1jzgk3ULP.1RtOUtjCOXiaWUOCOaJN4gkJ0GjmsIm/D01Wf7i6', NULL, 'h8gjHVzTTAIpsaJamvdZldtjJQJgz3zYgla5so9bbnf5UYRdms4jHITIWIY6', NULL, '2017-10-07 08:13:13', '2017-09-20 08:53:54', '2017-10-07 08:20:51', '2017-09-20 08:53:54', NULL, NULL),
(3, 'Developer', 'Developer', 'developer@mail.com', '0123456789', NULL, '1006ce8ab2b1d2904520e64acf7e13babdb80113.png', 'Mme', NULL, '$2y$10$Her1jzgk3ULP.1RtOUtjCOXiaWUOCOaJN4gkJ0GjmsIm/D01Wf7i6', NULL, 'hoSmDxzPyy7rES7AwGKeHQwTo2bwcb6MkpVMf71POyOOIQ4oMM4EWMTfvVQh', NULL, '2017-10-07 07:52:39', '2017-09-20 08:53:54', '2017-10-07 07:52:39', '2017-09-20 08:53:54', NULL, NULL),
(4, 'Analytics', 'Analytics', 'analytics@mail.com', '0123456789', NULL, '1006ce8ab2b1d2904520e64acf7e13babdb80113.png', 'Mr', NULL, '$2y$10$Her1jzgk3ULP.1RtOUtjCOXiaWUOCOaJN4gkJ0GjmsIm/D01Wf7i6', NULL, 'sLYixfMx6XU9Ge7fjbEksVWIKVKgqy5E6zUr6RYFsptf4FNorQad2pNxWs0U', NULL, '2017-10-07 07:53:03', '2017-09-20 08:53:54', '2017-10-07 07:53:03', '2017-09-20 08:53:54', NULL, NULL),
(5, 'Website', 'Website', 'website@mail.com', '0123456789', NULL, '1006ce8ab2b1d2904520e64acf7e13babdb80113.png', 'Mr', NULL, '$2y$10$Her1jzgk3ULP.1RtOUtjCOXiaWUOCOaJN4gkJ0GjmsIm/D01Wf7i6', NULL, 'rWwC2nrOVbg5zRr3QhDU4Sb7PR6Y5ljbk1PomqumaHh00N2qDM9B20N1szM2', NULL, '2017-10-07 07:53:27', '2017-09-20 08:53:54', '2017-10-07 07:53:27', '2017-09-20 08:53:54', NULL, NULL);
