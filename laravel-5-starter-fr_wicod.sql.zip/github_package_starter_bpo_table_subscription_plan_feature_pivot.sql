
-- --------------------------------------------------------

--
-- Structure de la table `subscription_plan_feature_pivot`
--

CREATE TABLE `subscription_plan_feature_pivot` (
  `id` int(10) UNSIGNED NOT NULL,
  `list_order` int(10) UNSIGNED NOT NULL DEFAULT '999',
  `subscription_plan_feature_id` int(10) UNSIGNED NOT NULL,
  `subscription_plan_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `subscription_plan_feature_pivot`
--

INSERT INTO `subscription_plan_feature_pivot` (`id`, `list_order`, `subscription_plan_feature_id`, `subscription_plan_id`) VALUES
(1, 1, 1, 1),
(2, 2, 2, 1),
(3, 3, 3, 1),
(4, 4, 4, 1),
(5, 5, 5, 1),
(6, 1, 5, 2),
(7, 2, 6, 2),
(8, 3, 7, 2),
(9, 4, 8, 2),
(10, 5, 9, 2),
(11, 6, 10, 2),
(12, 1, 10, 3),
(13, 2, 11, 3),
(14, 3, 12, 3),
(15, 4, 13, 3),
(16, 5, 14, 3),
(17, 6, 15, 3);
