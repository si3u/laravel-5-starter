
-- --------------------------------------------------------

--
-- Structure de la table `subscription_plans`
--

CREATE TABLE `subscription_plans` (
  `id` int(10) UNSIGNED NOT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cost` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `deleted_by` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `subscription_plans`
--

INSERT INTO `subscription_plans` (`id`, `is_featured`, `title`, `summary`, `cost`, `created_at`, `updated_at`, `deleted_at`, `created_by`, `updated_by`, `deleted_by`) VALUES
(1, 0, 'Basic', '', '19', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(2, 1, 'Plus', '', '99', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL),
(3, 0, 'Ultra', '', '199', '2017-09-20 08:53:54', '2017-09-20 08:53:54', NULL, 0, 0, NULL);
