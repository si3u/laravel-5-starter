
-- --------------------------------------------------------

--
-- Structure de la table `actus`
--

CREATE TABLE `actus` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `slug` varchar(200) NOT NULL,
  `summary` varchar(255) NOT NULL,
  `active_from` datetime NOT NULL,
  `active_to` datetime DEFAULT NULL,
  `facebook_shares` int(11) NOT NULL,
  `twitter_shares` int(11) NOT NULL,
  `pinterest_shares` int(11) NOT NULL,
  `googleplus_shares` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
