
-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_06_17_071843_create_log_logins_table', 1),
(4, '2017_06_17_113455_create_log_activities_table', 1),
(5, '2017_06_17_142413_create_log_admin_activities_table', 1),
(6, '2017_06_18_143920_create_navigation_admin_table', 1),
(7, '2017_06_18_175402_create_user_invites_table', 1),
(8, '2017_06_18_201544_create_navigation_admin_role_pivot_table', 1),
(9, '2017_06_19_060927_create_navigation_website_table', 1),
(10, '2017_06_19_122044_create_roles_table', 1),
(11, '2017_06_19_122132_create_role_user_pivot_table', 1),
(12, '2017_06_20_103224_create_notifications_table', 1),
(13, '2017_06_20_112814_create_changelogs_table', 1),
(14, '2017_06_20_114920_create_testimonials_table', 1),
(15, '2017_06_20_120924_create_countries_table', 1),
(16, '2017_06_20_124039_create_provinces_table', 1),
(17, '2017_06_20_124058_create_cities_table', 1),
(18, '2017_06_20_124120_create_suburbs_table', 1),
(19, '2017_06_20_164159_create_feedback_contact_us_table', 1),
(20, '2017_06_21_101323_create_banners_table', 1),
(21, '2017_07_04_175040_create_subscription_plans_table', 1),
(22, '2017_07_04_175120_create_subscription_plan_features_table', 1),
(23, '2017_07_05_094620_create_subscription_plan_feature_subscription_plan_pivot_table', 1),
(24, '2017_07_05_143321_create_tags_table', 1),
(25, '2017_07_08_094112_create_faq_categories_table', 1),
(26, '2017_07_08_102625_create_faqs_table', 1),
(27, '2017_07_10_152224_create_article_categories_table', 1),
(28, '2017_07_10_165218_create_articles_table', 1);
